# Command Line Arguments, Arrays,Passing Object to Methods.
## Problem Statement 2: 
#### Solve following sub problems,
2.1 Write a program that takes a String through Command Line argument and display the length of the string. Also display  the string into  uppercase and  check whether it is a  palindrome  or not. (Refer Java API Documentation)
2.2 Write a program that accepts two numbers from the Command Line and print them out. Then use a for loop  to print the next 13 numbers in the sequence where each number is the sum of  the previous two. For example:
input> java Problem2 1 3output> 1 3 4 7 11 18 29 47 76 123 322 521 843 1364
2.3Write a program that allows you  to  create an integer array of  18  elements with  the following values:
    int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0}. Perform the following computations, 
        a.Compute the sum of elements from index 0 to 14 and stores it at element 15
        b.Compute the average of all numbers and stores it at element 16 
        c.Identifies the smallest value from the array and stores it at element 17